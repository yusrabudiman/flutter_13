import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';

import 'package:provider/provider.dart';
import 'package:work_exe/pertemuan13/components/content_widget.dart';
import 'package:work_exe/pertemuan13/components/progress_indicator_widget.dart';
import 'package:work_exe/pertemuan13/components/slider_widget.dart';
import 'package:work_exe/pertemuan13/pertemuan13_provider.dart';

class Pertemuan13Screen extends StatefulWidget {
  const Pertemuan13Screen({super.key});

  @override
  State<Pertemuan13Screen> createState() => _Pertemuan13ScreenState();
}

class _Pertemuan13ScreenState extends State<Pertemuan13Screen> {
  @override
  Widget build(BuildContext context) {
    final prov = Provider.of<Pertemuan13Provider>(context);
    return Scaffold(
      appBar: AppBar(
        title: Text('Pertemuan13'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Duransi Memanggang: ${prov.sliderValue.round().toString()}'),
            const SlideWidget(),
            const Align(
              child: ProgressIndicatorWidget(),
              alignment: Alignment.bottomRight,
            ),
            SizedBox(height: 100),
            const ContentWidget()
          ],
        ),
      ),
    );
  }
}
